namespace RCS.API;

public class AppSettings
{
    public const string SectionName = "AppSettings";
    
    public string SQLConnectionString { get; set; }
    public string JwtSecret { get; set; }
}