namespace RCS.API.Softwares.Models.Responses;

public record IssueSubscriptionPaymentResponse(bool Success, string Message);
