namespace RCS.API.Softwares.Models.Responses;

public record CreateSubscriptionResponse(int Id, decimal Price);
