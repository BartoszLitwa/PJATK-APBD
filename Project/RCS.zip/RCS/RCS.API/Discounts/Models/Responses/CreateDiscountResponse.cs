namespace RCS.API.Discounts.Models.Responses;

public record CreateDiscountResponse(int Id, string Name);