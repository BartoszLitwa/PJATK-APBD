namespace RCS.API.Softwares.Models.Responses;

public record CreateSoftwareResponse(int Id, string Name);