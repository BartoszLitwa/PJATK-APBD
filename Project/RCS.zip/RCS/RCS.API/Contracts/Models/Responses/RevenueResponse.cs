namespace RCS.API.Contracts.Models.Responses;

public record RevenueResponse(decimal Revenue, string Currency);