namespace RCS.API.Contracts.Models.Responses;

public record IssuePaymentResponse(bool Success, string Message);
