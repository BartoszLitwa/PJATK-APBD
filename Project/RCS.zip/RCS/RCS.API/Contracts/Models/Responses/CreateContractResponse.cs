namespace RCS.API.Contracts.Models.Responses;

public record CreateContractResponse(int ContractId, decimal TotalPrice);