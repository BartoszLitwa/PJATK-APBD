namespace RCS.API.Contracts.Models.Requests;

public record CalculateRevenueRequest(string? ProductName, string? Currency);