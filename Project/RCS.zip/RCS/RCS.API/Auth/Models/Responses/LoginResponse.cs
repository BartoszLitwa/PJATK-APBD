namespace RCS.API.Auth.Models.Responses;

public record LoginResponse(string Token);