namespace RCS.API.Auth.Models.Requests;

public record LoginRequest(string Login, string Password);