namespace RCS.API.Softwares.Models.Requests;

public record CreateCurrencyRequest(string Code, decimal ExchangeRateToPLN);
