namespace RCS.API.Softwares.Models.Responses;

public record CreateCurrencyResponse(int Id, string Code);
