namespace Kolos.API.Clients.Models.Responses;

public class AddPaymentForSubscriptionForClientResponse
{
    public int IdPayment { get; set; }
}